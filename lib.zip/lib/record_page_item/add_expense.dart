import 'package:flutter/material.dart';

class AddExpense extends StatelessWidget {
  const AddExpense({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('新增花費'),
      ),
      body: Center(
        child: Hero(tag: 'uniqueTag', child: Icon(Icons.add)),
      ),
    );
  }
}