import 'package:flutter/material.dart';
import 'package:animal_app/record_page_item/top_card.dart';
import 'package:animal_app/record_page_item/expect_card.dart';
import 'package:animal_app/record_page_item/health_condition.dart';

class RecordPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('紀錄'),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(50.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 30,
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                child: Text('總花費',
                    style: TextStyle(fontSize: 20,)
                ),
              ),
            ),
            TopCard(
              balance: "\$ 10,000",
            ),
            SizedBox(
              height: 10,
            ),
            Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  child: Text('下個月預計花費',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12)
                  ),
                ),
            ),
            SizedBox(
              height: 10,
            ),

            ExpectCard(
                expectation: "\$ 8,000"
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                child: Text('健康狀態',
                    style: TextStyle(fontSize: 20,)
                ),
              ),
            ),
            HealthCondition(),

          ],
      ),
      ),
    );
  }
}