import 'package:flutter/material.dart';

class LinkPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('連結'),
      ),
      body: Center(child: Text("連結")),
    );
  }
}